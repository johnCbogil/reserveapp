//
//  DetailViewController.h
//  ReserveApp
//
//  Created by John Bogil on 8/1/15.
//  Copyright (c) 2015 John Bogil. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FoodItem.h"

@interface DetailViewController : UIViewController

@property (nonatomic, strong)FoodItem *foodItem;

@end
